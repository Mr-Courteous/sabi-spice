import type { Config } from "tailwindcss";

// Sabi Spice luxury culinary palette:
// Deep African forest emeralds, warm radiant amber spice gold, rich paprika accents, and warm ivory porcelain.
const config: Config = {
  content: ["./pages/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}", "./app/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        saffron: {
          DEFAULT: "#C87919", // Warm radiant amber spice gold (crisp contrast with white)
          light: "#F5C35E",   // Luminous golden honey (bright highlight, stars, badges on dark)
          lighter: "#FDF6EA", // Soft warm honey milk for subtle tinting
          dark: "#8F5008",    // Deep burnished cinnamon bronze
          muted: "#F7ECD7",   // Warm champagne pastry cream
          spice: "#D64527",   // Fiery suya / cayenne chili accent
          glow: "#FFD479",    // Golden sparkle
        },
        sabi: {
          dark: "#07180D",    // Midnight forest green
          black: "#0C2314",   // Deep obsidian evergreen (rich contrast for text & borders)
          charcoal: "#133821",// Regal dark emerald
          leaf: "#184D2B",    // Primary brand forest emerald (matches "Sabi" logo text)
          emerald: "#236B3D", // Vibrant botanical emerald for hovers & accents
          fresh: "#2E8A4E",   // Herbal green for badges & in-stock
          light: "#FAF8F5",   // Warm ivory alabaster background
          cream: "#F3ECE2",   // Warm linen biscuit cream
          grey: "#5A6B5C",    // Soft forest slate for legible secondary text
        },
      },
      fontFamily: {
        serif: ["'Bricolage Grotesque'", "system-ui", "sans-serif"],
        sans: ["'Manrope'", "system-ui", "sans-serif"],
        script: ["'Great Vibes'", "cursive"],
      },
      backgroundImage: {
        "saffron-gradient": "linear-gradient(135deg, #F5C35E 0%, #C87919 50%, #8F5008 100%)",
        "saffron-shimmer": "linear-gradient(90deg, #8F5008 0%, #C87919 25%, #FDE49E 50%, #C87919 75%, #8F5008 100%)",
        "sabi-gradient": "linear-gradient(145deg, #184D2B 0%, #133821 60%, #0C2314 100%)",
      },
      boxShadow: {
        "sabi-sm": "2px 2px 0 0 #0C2314",
        "sabi-md": "4px 4px 0 0 #0C2314",
        "sabi-lg": "6px 6px 0 0 #0C2314",
        "saffron-glow": "0 8px 24px -4px rgba(200, 121, 25, 0.35)",
        "emerald-glow": "0 8px 24px -4px rgba(24, 77, 43, 0.25)",
      },
      keyframes: {
        marquee: { from: { transform: "translateX(0)" }, to: { transform: "translateX(-50%)" } },
        goldShimmer: {
          "0%": { backgroundPosition: "100% 0" },
          "50%": { backgroundPosition: "0 0" },
          "100%": { backgroundPosition: "100% 0" },
        },
      },
      animation: {
        marquee: "marquee 28s linear infinite",
        shimmer: "goldShimmer 4s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
export default config;
